declare module "_102042_/l1/barbershopPro/layer_1_external/availabilitySlot.defs" {
    export const availabilitySlotTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "availabilitySlot";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 41;
            readonly planId: "plan-table-definition:availabilitySlot";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "availabilitySlot";
                readonly tableName: "availability_slot";
                readonly moduleId: "barbershopPro";
                readonly title: "Availability slot";
                readonly purpose: "Store staff availability intervals used for booking and walk-in suggestions.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "AvailabilitySlot";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "availability_slot_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Primary identifier for the availability slot.";
                }, {
                    readonly name: "staff_member_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "MDM staff member who owns this availability slot.";
                }, {
                    readonly name: "start_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Start time of the availability interval.";
                }, {
                    readonly name: "end_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "End time of the availability interval.";
                }, {
                    readonly name: "status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Lifecycle state of the slot (e.g., available, blocked, booked).";
                }, {
                    readonly name: "source";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Origin of the slot (e.g., schedule, override, booking).";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "When the slot was created.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "When the slot was last updated.";
                }];
                readonly primaryKey: readonly ["availability_slot_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "staff_member_id";
                    readonly targetEntity: "StaffMember";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "rule_mdm_exclusion";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "availability_slot_staff_start_idx";
                    readonly columns: readonly ["staff_member_id", "start_at"];
                    readonly unique: false;
                    readonly reason: "Lookup slots by staff and time range for booking and schedule views.";
                }, {
                    readonly indexName: "availability_slot_time_idx";
                    readonly columns: readonly ["start_at", "end_at"];
                    readonly unique: false;
                    readonly reason: "Range scans for walk-in slot suggestions and availability queries.";
                }, {
                    readonly indexName: "availability_slot_status_idx";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filter by lifecycle state for availability and booking workflows.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["appointmentNoOverlapPerStaff", "singleLocationScope"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/availabilitySlot.defs.ts";
                readonly exportName: "availabilitySlotTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default availabilitySlotTableDefinition;
}
declare module "_102042_/l1/barbershopPro/layer_1_external/inventoryLedgerEntry.defs" {
    export const inventoryLedgerEntryTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryLedgerEntry";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 43;
            readonly planId: "plan-table-definition:inventoryLedgerEntry";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryLedgerEntry";
                readonly tableName: "inventory_ledger_entry";
                readonly moduleId: "barbershopPro";
                readonly title: "Inventory ledger entry";
                readonly purpose: "Record stock changes for product sales and manual adjustments.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryLedger";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "inventory_ledger_entry_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Primary key for inventory ledger entry.";
                }, {
                    readonly name: "product_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Product whose stock changed.";
                }, {
                    readonly name: "sale_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Sale that caused the stock change, if applicable.";
                }, {
                    readonly name: "change_type";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Reason category for the stock change (sale, adjustment, correction).";
                }, {
                    readonly name: "quantity_change";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly description: "Signed quantity delta applied to stock.";
                }, {
                    readonly name: "balance_after";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly description: "Resulting stock level after applying this entry.";
                }, {
                    readonly name: "entry_status";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly default: "posted";
                    readonly description: "Lifecycle status of the ledger entry.";
                }, {
                    readonly name: "effective_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "When the stock change becomes effective.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "When the ledger entry was recorded.";
                }];
                readonly primaryKey: readonly ["inventory_ledger_entry_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "product_id";
                    readonly targetEntity: "Product";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Link entry to product for stock tracking.";
                }, {
                    readonly fieldName: "sale_id";
                    readonly targetEntity: "Sale";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Link entry to originating sale when applicable.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_ledger_entry_product_effective";
                    readonly columns: readonly ["product_id", "effective_at"];
                    readonly reason: "Lookup product ledger history and filter by date on inventory and checkout views.";
                }, {
                    readonly indexName: "idx_inventory_ledger_entry_sale";
                    readonly columns: readonly ["sale_id"];
                    readonly reason: "Resolve ledger entries created by a sale.";
                }, {
                    readonly indexName: "idx_inventory_ledger_entry_status";
                    readonly columns: readonly ["entry_status"];
                    readonly reason: "Filter by lifecycle status for operational workflows.";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["inventoryLevelByProduct", "inventoryAdjustmentsCount"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryCannotGoNegative", "singleLocationScope"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryLedgerEntry.defs.ts";
                readonly exportName: "inventoryLedgerEntryTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryLedgerEntryTableDefinition;
}
declare module "_102042_/l1/barbershopPro/layer_1_external/operationsMetrics.defs" {
    export const operationsMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "operationsMetrics";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 47;
            readonly planId: "plan-metric-table-definition:operationsMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "operationsMetrics";
                readonly tableName: "operations_metrics";
                readonly moduleId: "barbershopPro";
                readonly title: "Operations metrics";
                readonly purpose: "Track daily bookings, revenue, staff utilization, and appointment lifecycle trends to power the owner dashboard and operational summaries.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp when the metric event was recorded.";
                }, {
                    readonly name: "staff_member_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Staff member associated with the metric event.";
                }, {
                    readonly name: "service_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Service associated with the appointment or sale.";
                }, {
                    readonly name: "appointment_status";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "Lifecycle status of the appointment.";
                }, {
                    readonly name: "metric_category";
                    readonly type: "text";
                    readonly nullable: false;
                    readonly description: "Category of the metric: booking, sale, utilization, cancellation, noShow.";
                }, {
                    readonly name: "booking_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Number of bookings.";
                }, {
                    readonly name: "revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Revenue from services and products.";
                }, {
                    readonly name: "utilization_minutes";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Booked service minutes.";
                }, {
                    readonly name: "available_minutes";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Available staff minutes.";
                }, {
                    readonly name: "cancellation_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Number of cancelled appointments.";
                }, {
                    readonly name: "no_show_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Number of no-show appointments.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "staffMember";
                    readonly column: "staff_member_id";
                    readonly type: "uuid";
                    readonly description: "Staff member associated with the metric event.";
                }, {
                    readonly dimensionId: "service";
                    readonly column: "service_id";
                    readonly type: "uuid";
                    readonly description: "Service associated with the appointment or sale.";
                }, {
                    readonly dimensionId: "appointmentStatus";
                    readonly column: "appointment_status";
                    readonly type: "text";
                    readonly description: "Lifecycle status of the appointment.";
                }, {
                    readonly dimensionId: "metricCategory";
                    readonly column: "metric_category";
                    readonly type: "text";
                    readonly description: "Category of the metric: booking, sale, utilization, cancellation, noShow.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "bookingCount";
                    readonly column: "booking_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Number of bookings.";
                }, {
                    readonly measureId: "revenue";
                    readonly column: "revenue";
                    readonly aggregation: "sum";
                    readonly unit: "USD";
                    readonly description: "Revenue from services and products.";
                }, {
                    readonly measureId: "utilizationMinutes";
                    readonly column: "utilization_minutes";
                    readonly aggregation: "sum";
                    readonly unit: "minutes";
                    readonly description: "Booked service minutes.";
                }, {
                    readonly measureId: "availableMinutes";
                    readonly column: "available_minutes";
                    readonly aggregation: "sum";
                    readonly unit: "minutes";
                    readonly description: "Available staff minutes.";
                }, {
                    readonly measureId: "cancellationCount";
                    readonly column: "cancellation_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Number of cancelled appointments.";
                }, {
                    readonly measureId: "noShowCount";
                    readonly column: "no_show_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Number of no-show appointments.";
                }];
                readonly sourceWriteEvents: readonly ["createAppointmentUsecase", "rescheduleAppointmentUsecase", "cancelAppointmentUsecase", "checkInAppointmentUsecase", "completeAppointmentUsecase", "recordSaleUsecase", "updateStaffScheduleUsecase"];
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "operations_metrics_recorded_at_idx";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Primary time-series access for range scans.";
                    }, {
                        readonly indexName: "operations_metrics_staff_member_time_idx";
                        readonly columns: readonly ["staff_member_id", "recorded_at"];
                        readonly purpose: "Filter metrics by staff member over time.";
                    }, {
                        readonly indexName: "operations_metrics_service_time_idx";
                        readonly columns: readonly ["service_id", "recorded_at"];
                        readonly purpose: "Filter metrics by service over time.";
                    }, {
                        readonly indexName: "operations_metrics_status_time_idx";
                        readonly columns: readonly ["appointment_status", "recorded_at"];
                        readonly purpose: "Filter by appointment status over time.";
                    }, {
                        readonly indexName: "operations_metrics_category_time_idx";
                        readonly columns: readonly ["metric_category", "recorded_at"];
                        readonly purpose: "Filter by metric category over time.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["createAppointmentUsecase", "rescheduleAppointmentUsecase", "cancelAppointmentUsecase", "checkInAppointmentUsecase", "completeAppointmentUsecase", "recordSaleUsecase", "updateStaffScheduleUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/operationsMetrics.defs.ts";
                readonly exportName: "operationsMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default operationsMetricsMetricTableDefinition;
}
declare module "_102042_/l1/barbershopPro/layer_1_external/performanceMetrics.defs" {
    export const performanceMetricsMetricTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "performanceMetrics";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 49;
            readonly planId: "plan-metric-table-definition:performanceMetrics";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "performanceMetrics";
                readonly tableName: "performance_metrics";
                readonly moduleId: "barbershopPro";
                readonly title: "Performance metrics";
                readonly purpose: "Track staff commissions, service and product revenue, and sales performance for commission summaries and staff performance reviews.";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "recorded_at";
                readonly columns: readonly [{
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "When the performance metric was recorded.";
                }, {
                    readonly name: "staff_member_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Staff member who earned the commission or made the sale.";
                }, {
                    readonly name: "service_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Service sold.";
                }, {
                    readonly name: "product_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Product sold.";
                }, {
                    readonly name: "commission_rule_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Commission rule applied.";
                }, {
                    readonly name: "commission_amount";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Commission earned by staff.";
                }, {
                    readonly name: "service_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Revenue from services.";
                }, {
                    readonly name: "product_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Revenue from retail products.";
                }, {
                    readonly name: "total_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Total revenue from services and products.";
                }, {
                    readonly name: "sale_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Number of sales transactions.";
                }, {
                    readonly name: "units_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: 0;
                    readonly description: "Number of product units sold.";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "staffMember";
                    readonly column: "staff_member_id";
                    readonly type: "uuid";
                    readonly description: "Staff member who earned the commission or made the sale.";
                }, {
                    readonly dimensionId: "service";
                    readonly column: "service_id";
                    readonly type: "uuid";
                    readonly description: "Service sold.";
                }, {
                    readonly dimensionId: "product";
                    readonly column: "product_id";
                    readonly type: "uuid";
                    readonly description: "Product sold.";
                }, {
                    readonly dimensionId: "commissionRule";
                    readonly column: "commission_rule_id";
                    readonly type: "uuid";
                    readonly description: "Commission rule applied.";
                }];
                readonly measures: readonly [{
                    readonly measureId: "commissionAmount";
                    readonly column: "commission_amount";
                    readonly aggregation: "sum";
                    readonly unit: "USD";
                    readonly description: "Commission earned by staff.";
                }, {
                    readonly measureId: "serviceRevenue";
                    readonly column: "service_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "USD";
                    readonly description: "Revenue from services.";
                }, {
                    readonly measureId: "productRevenue";
                    readonly column: "product_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "USD";
                    readonly description: "Revenue from retail products.";
                }, {
                    readonly measureId: "totalRevenue";
                    readonly column: "total_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "USD";
                    readonly description: "Total revenue from services and products.";
                }, {
                    readonly measureId: "saleCount";
                    readonly column: "sale_count";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Number of sales transactions.";
                }, {
                    readonly measureId: "unitsSold";
                    readonly column: "units_sold";
                    readonly aggregation: "sum";
                    readonly unit: "count";
                    readonly description: "Number of product units sold.";
                }];
                readonly sourceWriteEvents: readonly ["recordSaleUsecase", "calculateCommissionUsecase", "createStaffMemberUsecase"];
                readonly hypertable: {
                    readonly timeColumn: "recorded_at";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "2 years";
                    readonly compressionPolicy: "30 days";
                    readonly indexes: readonly [{
                        readonly indexName: "performance_metrics_recorded_at_idx";
                        readonly columns: readonly ["recorded_at"];
                        readonly purpose: "Time-range scans for performance metrics.";
                    }, {
                        readonly indexName: "performance_metrics_staff_time_idx";
                        readonly columns: readonly ["staff_member_id", "recorded_at"];
                        readonly purpose: "Filter metrics by staff member and time.";
                    }, {
                        readonly indexName: "performance_metrics_service_time_idx";
                        readonly columns: readonly ["service_id", "recorded_at"];
                        readonly purpose: "Filter metrics by service and time.";
                    }, {
                        readonly indexName: "performance_metrics_product_time_idx";
                        readonly columns: readonly ["product_id", "recorded_at"];
                        readonly purpose: "Filter metrics by product and time.";
                    }, {
                        readonly indexName: "performance_metrics_commission_rule_time_idx";
                        readonly columns: readonly ["commission_rule_id", "recorded_at"];
                        readonly purpose: "Filter metrics by commission rule and time.";
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["recordSaleUsecase", "calculateCommissionUsecase", "createStaffMemberUsecase"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["singleLocationScope", "commissionCalculationRequired"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/performanceMetrics.defs.ts";
                readonly exportName: "performanceMetricsMetricTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default performanceMetricsMetricTableDefinition;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/adjustInventoryUsecase.defs" {
    export const adjustInventoryUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "adjustInventoryUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "adjustInventoryUsecase";
                readonly title: "Adjust inventory";
                readonly purpose: "Apply manual stock adjustments and update inventory ledger.";
                readonly actor: "manager";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["InventoryLedger", "Product"];
                readonly outputEntities: readonly ["InventoryLedger"];
                readonly readsTables: readonly ["inventory_ledger_entry", "product"];
                readonly writesTables: readonly ["inventory_ledger_entry"];
                readonly commands: readonly ["adjustInventory"];
                readonly rulesApplied: readonly ["inventoryCannotGoNegative", "singleLocationScope"];
            };
        };
    };
    export default adjustInventoryUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/bookAppointmentUsecase.defs" {
    export const bookAppointmentUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "bookAppointmentUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "bookAppointmentUsecase";
                readonly title: "Book appointment";
                readonly purpose: "Create an appointment and update availability while preventing overlaps.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Appointment", "AvailabilitySlot", "Customer", "StaffMember", "Service"];
                readonly outputEntities: readonly ["Appointment", "AvailabilitySlot"];
                readonly readsTables: readonly ["appointment", "availability_slot", "customer", "staff_member", "service"];
                readonly writesTables: readonly ["appointment", "availability_slot", "operations_metrics"];
                readonly commands: readonly ["bookAppointment"];
                readonly rulesApplied: readonly ["appointmentMustHaveCustomerStaffService", "appointmentNoOverlapPerStaff", "singleLocationScope"];
            };
        };
    };
    export default bookAppointmentUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/calculateCommissionUsecase.defs" {
    export const calculateCommissionUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "calculateCommissionUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "calculateCommissionUsecase";
                readonly title: "Calculate commissions";
                readonly purpose: "Recalculate commissions for a date range and update performance metrics.";
                readonly actor: "owner";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Sale", "CommissionRule", "StaffMember"];
                readonly outputEntities: readonly ["Sale", "CommissionRule"];
                readonly readsTables: readonly ["sale", "commission_rule", "staff_member"];
                readonly writesTables: readonly ["sale", "performance_metrics"];
                readonly commands: readonly ["runCommissionCalculation"];
                readonly rulesApplied: readonly ["commissionCalculationRequired", "singleLocationScope"];
            };
        };
    };
    export default calculateCommissionUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/cancelAppointmentUsecase.defs" {
    export const cancelAppointmentUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "cancelAppointmentUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "cancelAppointmentUsecase";
                readonly title: "Cancel appointment";
                readonly purpose: "Cancel an appointment and update operational metrics.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Appointment"];
                readonly outputEntities: readonly ["Appointment"];
                readonly readsTables: readonly ["appointment"];
                readonly writesTables: readonly ["appointment", "operations_metrics"];
                readonly commands: readonly ["cancelAppointment"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default cancelAppointmentUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/checkInAppointmentUsecase.defs" {
    export const checkInAppointmentUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "checkInAppointmentUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "checkInAppointmentUsecase";
                readonly title: "Check in appointment";
                readonly purpose: "Transition appointment to checked-in state.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Appointment"];
                readonly outputEntities: readonly ["Appointment"];
                readonly readsTables: readonly ["appointment"];
                readonly writesTables: readonly ["appointment", "operations_metrics"];
                readonly commands: readonly ["checkInAppointment"];
                readonly rulesApplied: readonly ["appointmentMustHaveCustomerStaffService", "singleLocationScope"];
            };
        };
    };
    export default checkInAppointmentUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/completeAppointmentUsecase.defs" {
    export const completeAppointmentUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "completeAppointmentUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "completeAppointmentUsecase";
                readonly title: "Complete appointment";
                readonly purpose: "Mark appointment completed before checkout.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Appointment"];
                readonly outputEntities: readonly ["Appointment"];
                readonly readsTables: readonly ["appointment"];
                readonly writesTables: readonly ["appointment", "operations_metrics"];
                readonly commands: readonly ["completeAppointment"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default completeAppointmentUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/createCustomerUsecase.defs" {
    export const createCustomerUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "createCustomerUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "createCustomerUsecase";
                readonly title: "Create customer";
                readonly purpose: "Create a customer profile for bookings and sales.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Customer"];
                readonly outputEntities: readonly ["Customer"];
                readonly readsTables: readonly ["customer"];
                readonly writesTables: readonly ["customer"];
                readonly commands: readonly ["createCustomer"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default createCustomerUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/createServiceUsecase.defs" {
    export const createServiceUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "createServiceUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "createServiceUsecase";
                readonly title: "Create service";
                readonly purpose: "Create a service with duration and price for bookings.";
                readonly actor: "manager";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Service"];
                readonly outputEntities: readonly ["Service"];
                readonly readsTables: readonly ["service"];
                readonly writesTables: readonly ["service"];
                readonly commands: readonly ["createService"];
                readonly rulesApplied: readonly ["serviceDurationPriceRequired", "singleLocationScope"];
            };
        };
    };
    export default createServiceUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/createStaffMemberUsecase.defs" {
    export const createStaffMemberUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "createStaffMemberUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "createStaffMemberUsecase";
                readonly title: "Create staff member";
                readonly purpose: "Create staff profile with role and commission settings.";
                readonly actor: "manager";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["StaffMember", "CommissionRule"];
                readonly outputEntities: readonly ["StaffMember", "CommissionRule"];
                readonly readsTables: readonly ["staff_member", "commission_rule"];
                readonly writesTables: readonly ["staff_member", "commission_rule", "performance_metrics"];
                readonly commands: readonly ["createStaffMember"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default createStaffMemberUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/recordSaleUsecase.defs" {
    export const recordSaleUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "recordSaleUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "recordSaleUsecase";
                readonly title: "Record sale";
                readonly purpose: "Record services/products sold, update inventory, commissions, and metrics.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Sale", "InventoryLedger", "Product", "CommissionRule", "StaffMember", "Appointment"];
                readonly outputEntities: readonly ["Sale", "InventoryLedger"];
                readonly readsTables: readonly ["sale", "inventory_ledger_entry", "product", "commission_rule", "staff_member", "appointment"];
                readonly writesTables: readonly ["sale", "inventory_ledger_entry", "operations_metrics", "performance_metrics"];
                readonly commands: readonly ["recordSale"];
                readonly rulesApplied: readonly ["saleRequiresCompletion", "inventoryCannotGoNegative", "commissionCalculationRequired", "singleLocationScope"];
            };
        };
    };
    export default recordSaleUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/requestUpsellSuggestionUsecase.defs" {
    export const requestUpsellSuggestionUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "requestUpsellSuggestionUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "requestUpsellSuggestionUsecase";
                readonly title: "Request upsell suggestions";
                readonly purpose: "Generate upsell recommendations using customer history and services.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Customer", "Service", "Sale"];
                readonly outputEntities: readonly ["Service"];
                readonly readsTables: readonly ["customer", "service", "sale"];
                readonly writesTables: readonly [];
                readonly commands: readonly ["requestUpsellSuggestion"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default requestUpsellSuggestionUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/requestWalkInSlotsUsecase.defs" {
    export const requestWalkInSlotsUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "requestWalkInSlotsUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "requestWalkInSlotsUsecase";
                readonly title: "Request walk-in time slots";
                readonly purpose: "Generate optimal walk-in time slots using availability and appointments.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["AvailabilitySlot", "Appointment", "StaffMember"];
                readonly outputEntities: readonly ["AvailabilitySlot"];
                readonly readsTables: readonly ["availability_slot", "appointment", "staff_member"];
                readonly writesTables: readonly ["availability_slot", "operations_metrics"];
                readonly commands: readonly ["requestWalkInSlots"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default requestWalkInSlotsUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/rescheduleAppointmentUsecase.defs" {
    export const rescheduleAppointmentUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "rescheduleAppointmentUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "rescheduleAppointmentUsecase";
                readonly title: "Reschedule appointment";
                readonly purpose: "Update appointment time/staff and availability while preventing overlaps.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Appointment", "AvailabilitySlot", "StaffMember"];
                readonly outputEntities: readonly ["Appointment", "AvailabilitySlot"];
                readonly readsTables: readonly ["appointment", "availability_slot", "staff_member"];
                readonly writesTables: readonly ["appointment", "availability_slot", "operations_metrics"];
                readonly commands: readonly ["rescheduleAppointment"];
                readonly rulesApplied: readonly ["appointmentNoOverlapPerStaff", "singleLocationScope"];
            };
        };
    };
    export default rescheduleAppointmentUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/updateCustomerUsecase.defs" {
    export const updateCustomerUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "updateCustomerUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "updateCustomerUsecase";
                readonly title: "Update customer";
                readonly purpose: "Update customer contact details and preferences.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Customer"];
                readonly outputEntities: readonly ["Customer"];
                readonly readsTables: readonly ["customer"];
                readonly writesTables: readonly ["customer"];
                readonly commands: readonly ["updateCustomer"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default updateCustomerUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/updateServiceUsecase.defs" {
    export const updateServiceUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "updateServiceUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "updateServiceUsecase";
                readonly title: "Update service";
                readonly purpose: "Update service duration and price for bookings.";
                readonly actor: "manager";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Service"];
                readonly outputEntities: readonly ["Service"];
                readonly readsTables: readonly ["service"];
                readonly writesTables: readonly ["service"];
                readonly commands: readonly ["updateService"];
                readonly rulesApplied: readonly ["serviceDurationPriceRequired", "singleLocationScope"];
            };
        };
    };
    export default updateServiceUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/updateStaffScheduleUsecase.defs" {
    export const updateStaffScheduleUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "updateStaffScheduleUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "updateStaffScheduleUsecase";
                readonly title: "Update staff schedule";
                readonly purpose: "Update availability slots for accurate booking.";
                readonly actor: "manager";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["AvailabilitySlot", "StaffMember"];
                readonly outputEntities: readonly ["AvailabilitySlot"];
                readonly readsTables: readonly ["availability_slot", "staff_member"];
                readonly writesTables: readonly ["availability_slot", "operations_metrics"];
                readonly commands: readonly ["updateStaffSchedule"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default updateStaffScheduleUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/viewCustomerHistoryUsecase.defs" {
    export const viewCustomerHistoryUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "viewCustomerHistoryUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "viewCustomerHistoryUsecase";
                readonly title: "View customer visit history";
                readonly purpose: "Retrieve appointments and sales for a customer.";
                readonly actor: "receptionist";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Customer"];
                readonly outputEntities: readonly ["Appointment", "Sale"];
                readonly readsTables: readonly ["customer", "appointment", "sale"];
                readonly writesTables: readonly [];
                readonly commands: readonly ["viewCustomerHistory"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default viewCustomerHistoryUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/viewDashboardUsecase.defs" {
    export const viewDashboardUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "viewDashboardUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "viewDashboardUsecase";
                readonly title: "View dashboard";
                readonly purpose: "Load operational KPIs and summaries for the dashboard.";
                readonly actor: "owner";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Appointment", "Sale", "StaffMember"];
                readonly outputEntities: readonly ["Appointment", "Sale", "StaffMember"];
                readonly readsTables: readonly ["operations_metrics", "performance_metrics", "appointment", "sale", "staff_member"];
                readonly writesTables: readonly [];
                readonly commands: readonly ["viewDashboard"];
                readonly rulesApplied: readonly ["singleLocationScope"];
            };
        };
    };
    export default viewDashboardUsecaseUsecasePlan;
}
declare module "_102042_/l1/barbershopPro/layer_3_usecases/viewStaffPerformanceUsecase.defs" {
    export const viewStaffPerformanceUsecaseUsecasePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "usecase";
        readonly artifactId: "viewStaffPerformanceUsecase";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanUsecaseEntities";
            readonly stepId: 51;
            readonly planId: "plan-index-critic:usecasePlan:1";
        };
        readonly data: {
            readonly backendArchitecture: {
                readonly pattern: "layered";
                readonly layer1Responsibility: "Persist external and module-owned tables, including metrics tables in layer_1_external.";
                readonly layer2Responsibility: "Expose controllers/BFF endpoints that must call layer_3_usecases and never access tables directly.";
                readonly layer3Responsibility: "Implement business use cases, enforce rules, and be the only layer that reads/writes layer_1_external tables.";
            };
            readonly controllerRules: {
                readonly bffMustCallUsecases: true;
                readonly bffDirectTableAccessForbidden: true;
            };
            readonly usecase: {
                readonly usecaseId: "viewStaffPerformanceUsecase";
                readonly title: "View staff performance";
                readonly purpose: "Load staff KPIs and commission summaries.";
                readonly actor: "manager";
                readonly layer: "layer_3_usecases";
                readonly inputEntities: readonly ["Sale", "StaffMember", "CommissionRule"];
                readonly outputEntities: readonly ["Sale", "StaffMember", "CommissionRule"];
                readonly readsTables: readonly ["performance_metrics", "sale", "staff_member", "commission_rule"];
                readonly writesTables: readonly [];
                readonly commands: readonly ["viewStaffPerformance"];
                readonly rulesApplied: readonly ["commissionCalculationRequired", "singleLocationScope"];
            };
        };
    };
    export default viewStaffPerformanceUsecaseUsecasePlan;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102042_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102042_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102042_/l2/barbershopPro/adminMetricsDashboard.defs" {
    export const adminMetricsDashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "adminMetricsDashboard";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 70;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "adminMetricsDashboard";
                readonly pageName: "Admin metrics dashboard";
                readonly actor: "owner";
                readonly purpose: "Review detailed metrics tables for operations and performance.";
                readonly capabilities: readonly ["viewDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "timePeriod";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Time period to scope metrics (e.g., day, week, month).";
                }, {
                    readonly name: "dateRange";
                    readonly type: "object";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Optional start/end dates for metrics filtering.";
                }, {
                    readonly name: "filters";
                    readonly type: "object";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Optional dimension filters such as staff member, service, product, or status.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "ownerDashboard";
                    readonly trigger: "View metrics dashboard";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Metrics filters";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "metricsFilterControls";
                        readonly purpose: "Allow the owner to set time period and dimension filters for the metrics tables.";
                        readonly userActions: readonly ["Set time period", "Apply filters", "Reset filters"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Operations metrics table";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "operationsMetricsTable";
                        readonly purpose: "Display operational metrics table with bookings, revenue, utilization, and appointment status trends.";
                        readonly userActions: readonly ["View operations metrics", "Sort table", "Change aggregation window"];
                        readonly requiredEntities: readonly ["Appointment", "Sale", "StaffMember"];
                        readonly readsFields: readonly ["operationsMetrics.recorded_at", "operationsMetrics.staff_member_id", "operationsMetrics.service_id", "operationsMetrics.appointment_status", "operationsMetrics.metric_category", "operationsMetrics.booking_count", "operationsMetrics.revenue", "operationsMetrics.utilization_minutes", "operationsMetrics.available_minutes", "operationsMetrics.cancellation_count", "operationsMetrics.no_show_count"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }, {
                    readonly sectionName: "Performance metrics table";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "performanceMetricsTable";
                        readonly purpose: "Display staff performance metrics including commissions, service/product revenue, and sales totals.";
                        readonly userActions: readonly ["View performance metrics", "Sort table", "Change aggregation window"];
                        readonly requiredEntities: readonly ["Sale", "StaffMember"];
                        readonly readsFields: readonly ["performanceMetrics.recorded_at", "performanceMetrics.staff_member_id", "performanceMetrics.service_id", "performanceMetrics.product_id", "performanceMetrics.commission_rule_id", "performanceMetrics.commission_amount", "performanceMetrics.service_revenue", "performanceMetrics.product_revenue", "performanceMetrics.total_revenue", "performanceMetrics.sale_count", "performanceMetrics.units_sold"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope", "RULE_commissionCalculationRequired"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAdminMetricsTables";
                readonly purpose: "Fetch metric tables for the admin dashboard.";
                readonly kind: "query";
                readonly input: {
                    readonly timePeriod: "string";
                    readonly dateRange: {
                        readonly startDate: "string";
                        readonly endDate: "string";
                    };
                    readonly filters: {
                        readonly staffMemberId: "string";
                        readonly serviceId: "string";
                        readonly productId: "string";
                        readonly appointmentStatus: "string";
                        readonly metricCategory: "string";
                    };
                };
                readonly output: {
                    readonly operationsMetricsTable: {
                        readonly rows: readonly [{
                            readonly recordedAt: "string";
                            readonly staffMemberId: "string";
                            readonly serviceId: "string";
                            readonly appointmentStatus: "string";
                            readonly metricCategory: "string";
                            readonly bookingCount: "number";
                            readonly revenue: "number";
                            readonly utilizationMinutes: "number";
                            readonly availableMinutes: "number";
                            readonly cancellationCount: "number";
                            readonly noShowCount: "number";
                        }];
                        readonly aggregationWindow: "string";
                    };
                    readonly performanceMetricsTable: {
                        readonly rows: readonly [{
                            readonly recordedAt: "string";
                            readonly staffMemberId: "string";
                            readonly serviceId: "string";
                            readonly productId: "string";
                            readonly commissionRuleId: "string";
                            readonly commissionAmount: "number";
                            readonly serviceRevenue: "number";
                            readonly productRevenue: "number";
                            readonly totalRevenue: "number";
                            readonly saleCount: "number";
                            readonly unitsSold: "number";
                        }];
                        readonly aggregationWindow: "string";
                    };
                };
                readonly readsEntities: readonly ["Appointment", "Sale", "StaffMember"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewDashboardUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_singleLocationScope"];
            }];
        };
    };
    export default adminMetricsDashboardPagePlan;
}
declare module "_102042_/l2/barbershopPro/appointmentCancel.defs" {
    export const appointmentCancelPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "appointmentCancel";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 85;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "appointmentCancel";
                readonly pageName: "Cancel appointment";
                readonly actor: "receptionist";
                readonly purpose: "Cancel an existing appointment and record the reason.";
                readonly capabilities: readonly ["bookAppointments"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["appointmentBooking"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer", "staffMember", "service"];
                readonly pageInputs: readonly [{
                    readonly name: "appointmentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identifier of the appointment to cancel.";
                    readonly entityRef: "Appointment";
                    readonly fieldRef: "Appointment.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "appointmentCalendar";
                    readonly trigger: "Cancel appointment";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "appointmentCalendar";
                    readonly trigger: "Cancellation confirmed";
                    readonly description: "Return to calendar after successful cancellation.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Appointment overview";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "appointmentSummary";
                        readonly purpose: "Show appointment, customer, staff, service, and time details before cancellation.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Appointment", "Customer", "StaffMember", "Service"];
                        readonly readsFields: readonly ["Appointment.id", "Appointment.lifecycleState", "Appointment.scheduledStart", "Appointment.scheduledEnd", "Appointment.customerId", "Appointment.staffMemberId", "Appointment.serviceId", "Customer.name", "Customer.phone", "StaffMember.name", "Service.name", "Service.duration", "Service.price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Cancellation reason";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "cancellationReasonForm";
                        readonly purpose: "Capture the cancellation reason from the receptionist.";
                        readonly userActions: readonly ["Enter cancellation reason"];
                        readonly requiredEntities: readonly ["Appointment"];
                        readonly readsFields: readonly ["Appointment.id"];
                        readonly writesFields: readonly ["Appointment.cancellationReason"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Confirm cancellation";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "cancelAppointmentAction";
                        readonly purpose: "Submit the cancellation request and confirm the update.";
                        readonly userActions: readonly ["Cancel appointment"];
                        readonly requiredEntities: readonly ["Appointment"];
                        readonly readsFields: readonly ["Appointment.id"];
                        readonly writesFields: readonly ["Appointment.lifecycleState", "Appointment.cancellationReason"];
                        readonly rulesApplied: readonly ["singleLocationScope"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAppointmentForCancel";
                readonly purpose: "Retrieve appointment details needed to review before cancellation.";
                readonly kind: "query";
                readonly input: {
                    readonly appointmentId: "string";
                };
                readonly output: {
                    readonly appointment: {
                        readonly id: "string";
                        readonly lifecycleState: "string";
                        readonly scheduledStart: "string";
                        readonly scheduledEnd: "string";
                        readonly customerId: "string";
                        readonly staffMemberId: "string";
                        readonly serviceId: "string";
                        readonly cancellationReason: "string|null";
                    };
                    readonly customer: {
                        readonly id: "string";
                        readonly name: "string";
                        readonly phone: "string";
                    };
                    readonly staffMember: {
                        readonly id: "string";
                        readonly name: "string";
                    };
                    readonly service: {
                        readonly id: "string";
                        readonly name: "string";
                        readonly duration: "number";
                        readonly price: "number";
                    };
                };
                readonly readsEntities: readonly ["Appointment", "Customer", "StaffMember", "Service"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["cancelAppointmentUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["singleLocationScope"];
            }, {
                readonly commandName: "cancelAppointment";
                readonly purpose: "Cancel the appointment and store the cancellation reason.";
                readonly kind: "command";
                readonly input: {
                    readonly appointmentId: "string";
                    readonly reason: "string";
                };
                readonly output: {
                    readonly appointmentId: "string";
                    readonly lifecycleState: "string";
                    readonly cancelledAt: "string";
                    readonly cancellationReason: "string";
                    readonly confirmationMessage: "string";
                };
                readonly readsEntities: readonly ["Appointment"];
                readonly writesEntities: readonly ["Appointment"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["cancelAppointmentUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["singleLocationScope"];
            }];
        };
    };
    export default appointmentCancelPagePlan;
}
declare module "_102042_/l2/barbershopPro/appointmentCheckIn.defs" {
    export const appointmentCheckInPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "appointmentCheckIn";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 87;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "appointmentCheckIn";
                readonly pageName: "Check in appointment";
                readonly actor: "receptionist";
                readonly purpose: "Mark the customer as checked in and start the service.";
                readonly capabilities: readonly ["checkInAndCheckout"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["checkInCheckout"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer", "staffMember", "service"];
                readonly pageInputs: readonly [{
                    readonly name: "appointmentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "Appointment identifier for check-in.";
                    readonly entityRef: "Appointment";
                    readonly fieldRef: "Appointment.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "appointmentDetail";
                    readonly trigger: "Check in";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "appointmentDetail";
                    readonly trigger: "Check-in completed";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Check-in confirmation";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "checkInConfirmation";
                        readonly purpose: "Confirm the check-in action for the selected appointment.";
                        readonly userActions: readonly ["Check in appointment"];
                        readonly requiredEntities: readonly ["Appointment"];
                        readonly readsFields: readonly ["Appointment.id"];
                        readonly writesFields: readonly ["Appointment.status"];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope", "RULE_appointmentMustHaveCustomerStaffService"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "checkInAppointment";
                readonly purpose: "Record appointment check-in.";
                readonly kind: "command";
                readonly input: {
                    readonly appointmentId: "string";
                };
                readonly output: {
                    readonly appointmentId: "string";
                    readonly status: "string";
                    readonly checkedInAt: "string";
                };
                readonly readsEntities: readonly ["Appointment"];
                readonly writesEntities: readonly ["Appointment"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["checkInAppointmentUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_appointmentMustHaveCustomerStaffService", "RULE_singleLocationScope"];
            }];
        };
    };
    export default appointmentCheckInPagePlan;
}
declare module "_102042_/l2/barbershopPro/appointmentCheckout.defs" {
    export const appointmentCheckoutPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "appointmentCheckout";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 88;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "appointmentCheckout";
                readonly pageName: "Complete appointment";
                readonly actor: "receptionist";
                readonly purpose: "Finalize the appointment and prepare for sale recording.";
                readonly capabilities: readonly ["checkInAndCheckout"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["checkInCheckout"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer", "staffMember", "service"];
                readonly pageInputs: readonly [{
                    readonly name: "appointmentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Appointment identifier to complete.";
                    readonly entityRef: "Appointment";
                    readonly fieldRef: "Appointment.appointmentId";
                }, {
                    readonly name: "appointmentSummary";
                    readonly type: "object";
                    readonly required: false;
                    readonly sources: readonly ["previousStepResult", "cache"];
                    readonly description: "Summary details from the prior step for display before completion.";
                    readonly entityRef: "Appointment";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "appointmentDetail";
                    readonly trigger: "Complete appointment";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "recordSale";
                    readonly trigger: "Proceed to sale";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Appointment summary";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "appointmentSummaryCard";
                        readonly purpose: "Show the appointment details to confirm before completion.";
                        readonly userActions: readonly ["Review appointment details"];
                        readonly requiredEntities: readonly ["Appointment"];
                        readonly readsFields: readonly ["Appointment.appointmentId", "Appointment.status", "Appointment.customerId", "Appointment.staffMemberId", "Appointment.serviceId", "Appointment.startTime", "Appointment.endTime"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Complete appointment";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "completeAppointmentAction";
                        readonly purpose: "Mark the appointment as completed to enable sale recording.";
                        readonly userActions: readonly ["Complete appointment"];
                        readonly requiredEntities: readonly ["Appointment"];
                        readonly readsFields: readonly ["Appointment.appointmentId", "Appointment.status"];
                        readonly writesFields: readonly ["Appointment.status"];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "completeAppointment";
                readonly purpose: "Mark appointment as completed.";
                readonly kind: "mutation";
                readonly input: {
                    readonly appointmentId: "string";
                };
                readonly output: {
                    readonly appointment: {
                        readonly appointmentId: "string";
                        readonly status: "string";
                    };
                };
                readonly readsEntities: readonly ["Appointment"];
                readonly writesEntities: readonly ["Appointment"];
                readonly readsTables: readonly ["appointment"];
                readonly writesTables: readonly ["appointment", "operations_metrics"];
                readonly usecaseRefs: readonly ["completeAppointmentUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_singleLocationScope"];
            }];
        };
    };
    export default appointmentCheckoutPagePlan;
}
declare module "_102042_/l2/barbershopPro/appointmentConfirm.defs" {
    export const appointmentConfirmPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "appointmentConfirm";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 83;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "appointmentConfirm";
                readonly pageName: "Confirm appointment";
                readonly actor: "receptionist";
                readonly purpose: "Confirm the appointment booking after selecting customer, staff, service, and time.";
                readonly capabilities: readonly ["bookAppointments"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["appointmentBooking"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer", "staffMember", "service"];
                readonly pageInputs: readonly [{
                    readonly name: "appointmentDraftId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identifier of the draft appointment to be confirmed.";
                    readonly entityRef: "Appointment";
                    readonly fieldRef: "Appointment.id";
                }, {
                    readonly name: "appointmentDraftSummary";
                    readonly type: "object";
                    readonly required: false;
                    readonly sources: readonly ["previousStepResult"];
                    readonly description: "Summary of selected customer, staff, service, and time for confirmation display.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "appointmentBooking";
                    readonly trigger: "Review appointment";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "appointmentDetail";
                    readonly trigger: "Appointment confirmed";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Appointment summary";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "appointmentSummaryCard";
                        readonly purpose: "Review the selected customer, staff member, service, and time before confirming.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Customer", "StaffMember", "Service", "Appointment"];
                        readonly readsFields: readonly ["Customer.id", "Customer.displayName", "StaffMember.id", "StaffMember.displayName", "Service.id", "Service.name", "Service.duration", "Service.price", "Appointment.scheduledStart", "Appointment.scheduledEnd"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["appointmentMustHaveCustomerStaffService"];
                    }];
                }, {
                    readonly sectionName: "Confirmation";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "confirmAppointmentAction";
                        readonly purpose: "Confirm and book the appointment.";
                        readonly userActions: readonly ["Book appointment"];
                        readonly requiredEntities: readonly ["Appointment", "AvailabilitySlot", "Customer", "StaffMember", "Service"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Appointment.id", "Appointment.lifecycleState", "AvailabilitySlot.status"];
                        readonly rulesApplied: readonly ["appointmentMustHaveCustomerStaffService", "appointmentNoOverlapPerStaff"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "confirmAppointment";
                readonly purpose: "Create the appointment record and book the selected availability slot.";
                readonly kind: "command";
                readonly input: {
                    readonly appointmentDraftId: "string";
                };
                readonly output: {
                    readonly appointmentId: "string";
                    readonly appointmentLifecycleState: "string";
                    readonly confirmationMessage: "string";
                };
                readonly readsEntities: readonly ["Appointment", "AvailabilitySlot", "Customer", "StaffMember", "Service"];
                readonly writesEntities: readonly ["Appointment", "AvailabilitySlot"];
                readonly readsTables: readonly ["appointment", "availability_slot", "customer", "staff_member", "service"];
                readonly writesTables: readonly ["appointment", "availability_slot", "operations_metrics"];
                readonly usecaseRefs: readonly ["bookAppointmentUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["appointmentMustHaveCustomerStaffService", "appointmentNoOverlapPerStaff"];
            }];
        };
    };
    export default appointmentConfirmPagePlan;
}
declare module "_102042_/l2/barbershopPro/appointmentDetail.defs" {
    export const appointmentDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "appointmentDetail";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 86;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "appointmentDetail";
                readonly pageName: "Appointment details";
                readonly actor: "receptionist";
                readonly purpose: "Review appointment details and proceed to check-in or checkout.";
                readonly capabilities: readonly ["bookAppointments", "checkInAndCheckout"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["appointmentBooking", "checkInCheckout"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer", "staffMember", "service"];
                readonly pageInputs: readonly [{
                    readonly name: "appointmentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identifier of the appointment to display.";
                    readonly entityRef: "Appointment";
                    readonly fieldRef: "Appointment.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "appointmentCalendar";
                    readonly trigger: "View appointment";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "appointmentCheckIn";
                    readonly trigger: "Check in";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "appointmentCheckout";
                    readonly trigger: "Complete appointment";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "recordSale";
                    readonly trigger: "Record sale";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Appointment summary";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "appointmentSummaryPanel";
                        readonly purpose: "Show appointment status, schedule, and key details.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Appointment"];
                        readonly readsFields: readonly ["Appointment.id", "Appointment.lifecycleState", "Appointment.startTime", "Appointment.endTime", "Appointment.notes", "Appointment.serviceIds", "Appointment.customerId", "Appointment.staffMemberId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Customer and staff";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "customerProfileSummary";
                        readonly purpose: "Show the customer associated with the appointment.";
                        readonly userActions: readonly ["View customer profile"];
                        readonly requiredEntities: readonly ["Customer"];
                        readonly readsFields: readonly ["Customer.id", "Customer.fullName", "Customer.phone", "Customer.email"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "staffMemberSummary";
                        readonly purpose: "Show the assigned staff member.";
                        readonly userActions: readonly ["View staff schedule"];
                        readonly requiredEntities: readonly ["StaffMember"];
                        readonly readsFields: readonly ["StaffMember.id", "StaffMember.fullName", "StaffMember.role"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Services";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "serviceListSummary";
                        readonly purpose: "List services linked to the appointment.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Service"];
                        readonly readsFields: readonly ["Service.id", "Service.name", "Service.duration", "Service.price"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAppointmentDetail";
                readonly purpose: "Load appointment details, customer, staff, and services.";
                readonly kind: "query";
                readonly input: {
                    readonly appointmentId: "string";
                };
                readonly output: {
                    readonly appointment: {
                        readonly id: "string";
                        readonly lifecycleState: "string";
                        readonly startTime: "string";
                        readonly endTime: "string";
                        readonly notes: "string";
                        readonly customerId: "string";
                        readonly staffMemberId: "string";
                        readonly serviceIds: readonly ["string"];
                    };
                    readonly customer: {
                        readonly id: "string";
                        readonly fullName: "string";
                        readonly phone: "string";
                        readonly email: "string";
                    };
                    readonly staffMember: {
                        readonly id: "string";
                        readonly fullName: "string";
                        readonly role: "string";
                    };
                    readonly services: readonly [{
                        readonly id: "string";
                        readonly name: "string";
                        readonly duration: "number";
                        readonly price: "number";
                    }];
                };
                readonly readsEntities: readonly ["Appointment", "Customer", "StaffMember", "Service"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["appointment"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly [];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default appointmentDetailPagePlan;
}
declare module "_102042_/l2/barbershopPro/commissionCalculation.defs" {
    export const commissionCalculationPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "commissionCalculation";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 92;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "commissionCalculation";
                readonly pageName: "Commission calculation";
                readonly actor: "owner";
                readonly purpose: "Run commission calculations and review results.";
                readonly capabilities: readonly ["calculateCommissions"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["commissionCalculation"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["commissionRule", "staffMember"];
                readonly pageInputs: readonly [{
                    readonly name: "dateRange";
                    readonly type: "dateRange";
                    readonly required: true;
                    readonly sources: readonly ["userInput"];
                    readonly description: "Start and end dates for commission calculation window.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "ownerDashboard";
                    readonly trigger: "Run commission calculation";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Calculation window";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "dateRangeSelector";
                        readonly purpose: "Capture the date range for commission calculation.";
                        readonly userActions: readonly ["Select start date", "Select end date"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["commissionCalculationRequired"];
                    }];
                }, {
                    readonly sectionName: "Run calculation";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "commissionCalculationAction";
                        readonly purpose: "Trigger commission calculation for the selected date range.";
                        readonly userActions: readonly ["Run commission calculation"];
                        readonly requiredEntities: readonly ["Sale", "CommissionRule", "StaffMember"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["commissionCalculationRequired"];
                    }];
                }, {
                    readonly sectionName: "Results summary";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "commissionTotalsByStaff";
                        readonly purpose: "Show commission totals by staff for the selected range.";
                        readonly userActions: readonly ["Review totals", "Sort by commission amount"];
                        readonly requiredEntities: readonly ["StaffMember"];
                        readonly readsFields: readonly ["StaffMember.name", "StaffMember.id"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["commissionCalculationRequired"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "runCommissionCalculation";
                readonly purpose: "Trigger commission calculation and return summary.";
                readonly kind: "command";
                readonly input: {
                    readonly dateRange: {
                        readonly startDate: "date";
                        readonly endDate: "date";
                    };
                };
                readonly output: {
                    readonly status: "string";
                    readonly summary: {
                        readonly totalCommissionAmount: "number";
                        readonly staffTotals: readonly [{
                            readonly staffMemberId: "uuid";
                            readonly staffMemberName: "string";
                            readonly commissionAmount: "number";
                            readonly serviceRevenue: "number";
                            readonly productRevenue: "number";
                            readonly totalRevenue: "number";
                            readonly saleCount: "number";
                        }];
                    };
                };
                readonly readsEntities: readonly ["Sale", "CommissionRule", "StaffMember"];
                readonly writesEntities: readonly ["Sale"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["calculateCommissionUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["commissionCalculationRequired"];
            }];
        };
    };
    export default commissionCalculationPagePlan;
}
declare module "_102042_/l2/barbershopPro/customerCreate.defs" {
    export const customerCreatePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "customerCreate";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 72;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "customerCreate";
                readonly pageName: "New customer";
                readonly actor: "receptionist";
                readonly purpose: "Capture customer details for new profiles.";
                readonly capabilities: readonly ["manageCustomers"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "customerList";
                    readonly trigger: "New customer";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "customerDetail";
                    readonly trigger: "Save customer";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Customer details";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "CustomerProfileForm";
                        readonly purpose: "Collect customer identity and contact details for profile creation.";
                        readonly userActions: readonly ["Enter identity details", "Enter contact details"];
                        readonly requiredEntities: readonly ["Customer"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Customer.firstName", "Customer.lastName", "Customer.preferredName", "Customer.phone", "Customer.email", "Customer.birthDate", "Customer.notes"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Create customer";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "CreateCustomerAction";
                        readonly purpose: "Submit the new customer profile.";
                        readonly userActions: readonly ["Create customer"];
                        readonly requiredEntities: readonly ["Customer"];
                        readonly readsFields: readonly ["Customer.firstName", "Customer.lastName", "Customer.preferredName", "Customer.phone", "Customer.email", "Customer.birthDate", "Customer.notes"];
                        readonly writesFields: readonly ["Customer.customerId"];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "createCustomer";
                readonly purpose: "Create a new customer profile.";
                readonly kind: "command";
                readonly input: {
                    readonly customerProfile: {
                        readonly firstName: "string";
                        readonly lastName: "string";
                        readonly preferredName: "string";
                        readonly phone: "string";
                        readonly email: "string";
                        readonly birthDate: "string";
                        readonly notes: "string";
                    };
                };
                readonly output: {
                    readonly customer: {
                        readonly customerId: "string";
                        readonly firstName: "string";
                        readonly lastName: "string";
                        readonly preferredName: "string";
                        readonly phone: "string";
                        readonly email: "string";
                        readonly birthDate: "string";
                        readonly notes: "string";
                        readonly createdAt: "string";
                    };
                };
                readonly readsEntities: readonly ["Customer"];
                readonly writesEntities: readonly ["Customer"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["createCustomerUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["singleLocationScope"];
            }];
        };
    };
    export default customerCreatePagePlan;
}
declare module "_102042_/l2/barbershopPro/customerDetail.defs" {
    export const customerDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "customerDetail";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 73;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "customerDetail";
                readonly pageName: "Customer profile";
                readonly actor: "receptionist";
                readonly purpose: "Review and update customer details and visit history.";
                readonly capabilities: readonly ["manageCustomers"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["customer"];
                readonly pageInputs: readonly [{
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Customer identifier for loading profile and history.";
                    readonly entityRef: "Customer";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "customerList";
                    readonly trigger: "Select customer";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Customer details";
                    readonly mode: "viewEdit";
                    readonly organisms: readonly [{
                        readonly organismName: "CustomerProfileForm";
                        readonly purpose: "View and update customer contact details and preferences.";
                        readonly userActions: readonly ["Edit customer details", "Save customer updates"];
                        readonly requiredEntities: readonly ["Customer"];
                        readonly readsFields: readonly ["Customer.id", "Customer.fullName", "Customer.phone", "Customer.email", "Customer.preferences", "Customer.notes"];
                        readonly writesFields: readonly ["Customer.fullName", "Customer.phone", "Customer.email", "Customer.preferences", "Customer.notes"];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }, {
                    readonly sectionName: "Visit history";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "CustomerVisitHistoryList";
                        readonly purpose: "Review appointments and sales for this customer.";
                        readonly userActions: readonly ["View appointment history", "View sales history"];
                        readonly requiredEntities: readonly ["Appointment", "Sale"];
                        readonly readsFields: readonly ["Appointment.id", "Appointment.scheduledAt", "Appointment.serviceName", "Appointment.staffName", "Appointment.status", "Sale.id", "Sale.completedAt", "Sale.totalAmount", "Sale.itemsSummary"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getCustomerProfile";
                readonly purpose: "Load customer details and visit history.";
                readonly kind: "query";
                readonly input: {
                    readonly customerId: "string";
                };
                readonly output: {
                    readonly customer: {
                        readonly id: "string";
                        readonly fullName: "string";
                        readonly phone: "string";
                        readonly email: "string";
                        readonly preferences: "object";
                        readonly notes: "string";
                    };
                    readonly visitHistory: {
                        readonly appointments: readonly [{
                            readonly id: "string";
                            readonly scheduledAt: "string";
                            readonly serviceName: "string";
                            readonly staffName: "string";
                            readonly status: "string";
                        }];
                        readonly sales: readonly [{
                            readonly id: "string";
                            readonly completedAt: "string";
                            readonly totalAmount: "number";
                            readonly itemsSummary: "string";
                        }];
                    };
                };
                readonly readsEntities: readonly ["Customer", "Appointment", "Sale"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["appointment", "sale"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewCustomerHistoryUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_singleLocationScope"];
            }, {
                readonly commandName: "updateCustomer";
                readonly purpose: "Save customer profile updates.";
                readonly kind: "command";
                readonly input: {
                    readonly customerId: "string";
                    readonly updates: {
                        readonly fullName: "string";
                        readonly phone: "string";
                        readonly email: "string";
                        readonly preferences: "object";
                        readonly notes: "string";
                    };
                };
                readonly output: {
                    readonly customer: {
                        readonly id: "string";
                        readonly fullName: "string";
                        readonly phone: "string";
                        readonly email: "string";
                        readonly preferences: "object";
                        readonly notes: "string";
                    };
                };
                readonly readsEntities: readonly ["Customer"];
                readonly writesEntities: readonly ["Customer"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["updateCustomerUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_singleLocationScope"];
            }];
        };
    };
    export default customerDetailPagePlan;
}
declare module "_102042_/l2/barbershopPro/inventoryAdjust.defs" {
    export const inventoryAdjustPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryAdjust";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 91;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryAdjust";
                readonly pageName: "Adjust inventory";
                readonly actor: "manager";
                readonly purpose: "Record inventory adjustments with reason codes.";
                readonly capabilities: readonly ["trackInventory"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["product"];
                readonly pageInputs: readonly [{
                    readonly name: "productId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Product to adjust inventory for.";
                    readonly entityRef: "Product";
                    readonly fieldRef: "Product.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "inventoryList";
                    readonly trigger: "Adjust inventory";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryList";
                    readonly trigger: "Adjustment saved";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Product context";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ProductSummary";
                        readonly purpose: "Show the selected product and current stock context for the adjustment.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Product", "InventoryLedger"];
                        readonly readsFields: readonly ["Product.id", "Product.title", "Product.sku", "InventoryLedger.balance_after", "InventoryLedger.effective_at"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegative"];
                    }];
                }, {
                    readonly sectionName: "Adjustment entry";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "InventoryAdjustmentForm";
                        readonly purpose: "Capture adjustment quantity and reason and submit the adjustment.";
                        readonly userActions: readonly ["Adjust inventory"];
                        readonly requiredEntities: readonly ["InventoryLedger", "Product"];
                        readonly readsFields: readonly ["Product.id"];
                        readonly writesFields: readonly ["InventoryLedger.change_type", "InventoryLedger.quantity_change", "InventoryLedger.entry_status", "InventoryLedger.effective_at", "InventoryLedger.created_at", "InventoryLedger.balance_after"];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegative"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getProductAdjustmentContext";
                readonly purpose: "Load product details and current stock context for the adjustment.";
                readonly kind: "query";
                readonly input: {
                    readonly productId: "uuid";
                };
                readonly output: {
                    readonly product: {
                        readonly id: "uuid";
                        readonly title: "string";
                        readonly sku: "string";
                    };
                    readonly currentStock: {
                        readonly balanceAfter: "integer";
                        readonly effectiveAt: "timestamptz";
                    };
                };
                readonly readsEntities: readonly ["Product", "InventoryLedger"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_ledger_entry"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["adjustInventoryUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryCannotGoNegative"];
            }, {
                readonly commandName: "adjustInventory";
                readonly purpose: "Record inventory adjustment and update ledger.";
                readonly kind: "command";
                readonly input: {
                    readonly productId: "uuid";
                    readonly quantity: "integer";
                    readonly reason: "string";
                };
                readonly output: {
                    readonly ledgerEntry: {
                        readonly inventoryLedgerEntryId: "uuid";
                        readonly productId: "uuid";
                        readonly changeType: "string";
                        readonly quantityChange: "integer";
                        readonly balanceAfter: "integer";
                        readonly entryStatus: "string";
                        readonly effectiveAt: "timestamptz";
                        readonly createdAt: "timestamptz";
                    };
                    readonly updatedStock: {
                        readonly productId: "uuid";
                        readonly balanceAfter: "integer";
                    };
                };
                readonly readsEntities: readonly ["Product", "InventoryLedger"];
                readonly writesEntities: readonly ["InventoryLedger"];
                readonly readsTables: readonly ["inventory_ledger_entry"];
                readonly writesTables: readonly ["inventory_ledger_entry"];
                readonly usecaseRefs: readonly ["adjustInventoryUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryCannotGoNegative"];
            }];
        };
    };
    export default inventoryAdjustPagePlan;
}
declare module "_102042_/l2/barbershopPro/inventoryList.defs" {
    export const inventoryListPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryList";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 90;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryList";
                readonly pageName: "Inventory";
                readonly actor: "manager";
                readonly purpose: "Review inventory levels and adjustments.";
                readonly capabilities: readonly ["trackInventory"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["product"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "inventoryAdjust";
                    readonly trigger: "Adjust inventory";
                    readonly description: "Navigate to record an inventory adjustment.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Inventory overview";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "inventoryLevelsTable";
                        readonly purpose: "Display current stock levels per product with recent balance info.";
                        readonly userActions: readonly ["Adjust inventory", "Filter inventory", "View ledger summary"];
                        readonly requiredEntities: readonly ["Product", "InventoryLedger"];
                        readonly readsFields: readonly ["Product.productId", "Product.name", "Product.sku", "InventoryLedger.balance_after", "InventoryLedger.effective_at", "InventoryLedger.entry_status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegative"];
                    }, {
                        readonly organismName: "inventoryLedgerSummary";
                        readonly purpose: "Show recent inventory adjustments and totals.";
                        readonly userActions: readonly ["Filter by date", "View entry details"];
                        readonly requiredEntities: readonly ["InventoryLedger", "Product"];
                        readonly readsFields: readonly ["InventoryLedger.inventory_ledger_entry_id", "InventoryLedger.product_id", "InventoryLedger.change_type", "InventoryLedger.quantity_change", "InventoryLedger.balance_after", "InventoryLedger.entry_status", "InventoryLedger.effective_at", "Product.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegative"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getInventoryLevels";
                readonly purpose: "Load current inventory levels and ledger summary for inventory review.";
                readonly kind: "query";
                readonly input: {
                    readonly filters: {
                        readonly productQuery: "string?";
                        readonly status: "string?";
                        readonly fromDate: "string?";
                        readonly toDate: "string?";
                        readonly limit: "number?";
                        readonly offset: "number?";
                    };
                };
                readonly output: {
                    readonly inventoryLevels: readonly [{
                        readonly productId: "string";
                        readonly productName: "string";
                        readonly sku: "string";
                        readonly currentBalance: "number";
                        readonly lastUpdatedAt: "string";
                    }];
                    readonly ledgerSummary: readonly [{
                        readonly inventoryLedgerEntryId: "string";
                        readonly productId: "string";
                        readonly productName: "string";
                        readonly changeType: "string";
                        readonly quantityChange: "number";
                        readonly balanceAfter: "number";
                        readonly entryStatus: "string";
                        readonly effectiveAt: "string";
                    }];
                };
                readonly readsEntities: readonly ["Product", "InventoryLedger"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_ledger_entry"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["adjustInventoryUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryCannotGoNegative"];
            }];
        };
    };
    export default inventoryListPagePlan;
}
declare module "_102042_/l2/barbershopPro/ownerDashboard.defs" {
    export const ownerDashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "ownerDashboard";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 69;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "ownerDashboard";
                readonly pageName: "Owner dashboard";
                readonly actor: "owner";
                readonly purpose: "Monitor revenue, bookings, utilization, and operational trends.";
                readonly capabilities: readonly ["viewDashboard"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "dateRange";
                    readonly type: "dateRange";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Optional date range for dashboard metrics.";
                }, {
                    readonly name: "periodPreset";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Preset period such as today, weekToDate, or monthToDate.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "adminMetricsDashboard";
                    readonly trigger: "View metrics dashboard";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "commissionCalculation";
                    readonly trigger: "Run commission calculation";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "dashboardFilters";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "dateRangeSelector";
                        readonly purpose: "Allow the owner to choose the period for metrics.";
                        readonly userActions: readonly ["Select period", "Apply date range"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "kpiSummary";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "operationsMetricsSummary";
                        readonly purpose: "Show bookings, revenue, utilization, cancellations, and no-shows for the selected period.";
                        readonly userActions: readonly ["View KPI cards", "View trend sparkline"];
                        readonly requiredEntities: readonly ["Appointment", "Sale", "StaffMember"];
                        readonly readsFields: readonly ["operationsMetrics.bookingCount", "operationsMetrics.revenue", "operationsMetrics.utilizationMinutes", "operationsMetrics.availableMinutes", "operationsMetrics.cancellationCount", "operationsMetrics.noShowCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }, {
                        readonly organismName: "performanceMetricsSummary";
                        readonly purpose: "Show commission, service revenue, product revenue, and sales totals.";
                        readonly userActions: readonly ["View KPI cards", "View breakdown by staff"];
                        readonly requiredEntities: readonly ["Sale", "StaffMember"];
                        readonly readsFields: readonly ["performanceMetrics.commissionAmount", "performanceMetrics.serviceRevenue", "performanceMetrics.productRevenue", "performanceMetrics.totalRevenue", "performanceMetrics.saleCount", "performanceMetrics.unitsSold"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope", "RULE_commissionCalculationRequired"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOwnerDashboardMetrics";
                readonly purpose: "Load current operational and performance metrics for the owner view.";
                readonly kind: "query";
                readonly input: {
                    readonly dateRange: {
                        readonly start: "timestamptz";
                        readonly end: "timestamptz";
                    };
                    readonly periodPreset: "string";
                };
                readonly output: {
                    readonly operationsMetricsSummary: {
                        readonly bookingCount: "number";
                        readonly revenue: "number";
                        readonly utilizationMinutes: "number";
                        readonly availableMinutes: "number";
                        readonly cancellationCount: "number";
                        readonly noShowCount: "number";
                    };
                    readonly performanceMetricsSummary: {
                        readonly commissionAmount: "number";
                        readonly serviceRevenue: "number";
                        readonly productRevenue: "number";
                        readonly totalRevenue: "number";
                        readonly saleCount: "number";
                        readonly unitsSold: "number";
                    };
                    readonly asOf: "timestamptz";
                };
                readonly readsEntities: readonly ["Appointment", "Sale", "StaffMember"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewDashboardUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_singleLocationScope", "RULE_commissionCalculationRequired"];
            }];
        };
    };
    export default ownerDashboardPagePlan;
}
declare module "_102042_/l2/barbershopPro/recordSale.defs" {
    export const recordSalePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "recordSale";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 89;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "recordSale";
                readonly pageName: "Record sale";
                readonly actor: "receptionist";
                readonly purpose: "Record service or retail sale and capture payment details.";
                readonly capabilities: readonly ["checkInAndCheckout"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["checkInCheckout"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["product", "service"];
                readonly pageInputs: readonly [{
                    readonly name: "appointmentId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Appointment identifier when the sale is tied to a completed appointment.";
                    readonly entityRef: "Appointment";
                    readonly fieldRef: "Appointment.id";
                }, {
                    readonly name: "appointmentSummary";
                    readonly type: "object";
                    readonly required: false;
                    readonly sources: readonly ["previousStepResult"];
                    readonly description: "Appointment summary data passed from checkout to avoid a refetch.";
                    readonly entityRef: "Appointment";
                }, {
                    readonly name: "retailOnlyFlag";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly sources: readonly ["queryParam"];
                    readonly description: "Indicates the sale is retail-only without a linked appointment.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "appointmentDetail";
                    readonly trigger: "Record sale";
                }, {
                    readonly direction: "inbound";
                    readonly pageId: "appointmentCheckout";
                    readonly trigger: "Proceed to sale";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Sale context";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "AppointmentContextSummary";
                        readonly purpose: "Show the appointment summary when the sale is tied to a completed appointment.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Appointment", "StaffMember"];
                        readonly readsFields: readonly ["Appointment.id", "Appointment.status", "Appointment.serviceItems", "Appointment.customerName", "Appointment.staffMemberName", "Appointment.completedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["saleRequiresCompletion"];
                    }];
                }, {
                    readonly sectionName: "Sale items";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "SaleItemsEntry";
                        readonly purpose: "Capture service and product line items for the sale.";
                        readonly userActions: readonly ["Add service line item", "Add product line item", "Edit quantity", "Remove line item"];
                        readonly requiredEntities: readonly ["Sale"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Sale.lineItems", "Sale.subtotalAmount", "Sale.taxAmount", "Sale.totalAmount"];
                        readonly rulesApplied: readonly ["saleRequiresCompletion"];
                    }];
                }, {
                    readonly sectionName: "Payment and confirmation";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "PaymentDetailsForm";
                        readonly purpose: "Capture payment method and amounts for the sale.";
                        readonly userActions: readonly ["Select payment method", "Enter payment amount", "Add split payment"];
                        readonly requiredEntities: readonly ["Sale"];
                        readonly readsFields: readonly ["Sale.totalAmount"];
                        readonly writesFields: readonly ["Sale.payments", "Sale.paidAmount", "Sale.balanceDue"];
                        readonly rulesApplied: readonly ["saleRequiresCompletion"];
                    }, {
                        readonly organismName: "RecordSaleActionBar";
                        readonly purpose: "Confirm and record the sale with inventory and commission updates.";
                        readonly userActions: readonly ["Record sale"];
                        readonly requiredEntities: readonly ["Sale", "InventoryLedger", "CommissionRule", "StaffMember", "Appointment"];
                        readonly readsFields: readonly ["Sale.lineItems", "Sale.payments", "Sale.totalAmount", "Appointment.id", "Appointment.status"];
                        readonly writesFields: readonly ["Sale.id", "InventoryLedger.entryStatus"];
                        readonly rulesApplied: readonly ["saleRequiresCompletion", "commissionCalculationRequired"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "recordSale";
                readonly purpose: "Record service or retail sale for an appointment or retail-only checkout.";
                readonly kind: "command";
                readonly input: {
                    readonly appointmentId: "string (optional)";
                    readonly retailOnlyFlag: "boolean";
                    readonly lineItems: readonly [{
                        readonly itemType: "service | product";
                        readonly itemId: "string";
                        readonly description: "string (optional)";
                        readonly quantity: "number";
                        readonly unitPrice: "number";
                    }];
                    readonly payments: readonly [{
                        readonly method: "string";
                        readonly amount: "number";
                        readonly reference: "string (optional)";
                    }];
                    readonly notes: "string (optional)";
                };
                readonly output: {
                    readonly saleId: "string";
                    readonly receiptSummary: {
                        readonly totalAmount: "number";
                        readonly taxAmount: "number (optional)";
                        readonly paidAmount: "number";
                        readonly balanceDue: "number";
                    };
                };
                readonly readsEntities: readonly ["Appointment", "Product", "CommissionRule", "StaffMember"];
                readonly writesEntities: readonly ["Sale", "InventoryLedger"];
                readonly readsTables: readonly ["sale", "inventory_ledger_entry", "commission_rule", "staff_member", "appointment"];
                readonly writesTables: readonly ["sale", "inventory_ledger_entry", "operations_metrics", "performance_metrics"];
                readonly usecaseRefs: readonly ["recordSaleUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["saleRequiresCompletion", "inventoryCannotGoNegative", "commissionCalculationRequired", "singleLocationScope"];
            }];
        };
    };
    export default recordSalePagePlan;
}
declare module "_102042_/l2/barbershopPro/serviceCreate.defs" {
    export const serviceCreatePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "serviceCreate";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 79;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "serviceCreate";
                readonly pageName: "New service";
                readonly actor: "manager";
                readonly purpose: "Define a new service with duration and price.";
                readonly capabilities: readonly ["manageServices"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["service"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "serviceList";
                    readonly trigger: "New service";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "serviceDetail";
                    readonly trigger: "Save service";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Service details";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "ServiceForm";
                        readonly purpose: "Capture service name, duration, and price.";
                        readonly userActions: readonly ["Enter service name", "Enter duration", "Enter price"];
                        readonly requiredEntities: readonly ["Service"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["serviceName", "durationMinutes", "priceAmount"];
                        readonly rulesApplied: readonly ["serviceDurationPriceRequired"];
                    }];
                }, {
                    readonly sectionName: "Create service";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "CreateServiceAction";
                        readonly purpose: "Submit the new service for creation.";
                        readonly userActions: readonly ["Create service"];
                        readonly requiredEntities: readonly ["Service"];
                        readonly readsFields: readonly ["serviceName", "durationMinutes", "priceAmount"];
                        readonly writesFields: readonly ["serviceId"];
                        readonly rulesApplied: readonly ["serviceDurationPriceRequired"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "createService";
                readonly purpose: "Create a new service.";
                readonly kind: "command";
                readonly input: {
                    readonly serviceName: "string";
                    readonly durationMinutes: "number";
                    readonly priceAmount: "number";
                };
                readonly output: {
                    readonly serviceId: "string";
                    readonly serviceName: "string";
                    readonly durationMinutes: "number";
                    readonly priceAmount: "number";
                };
                readonly readsEntities: readonly ["Service"];
                readonly writesEntities: readonly ["Service"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["createServiceUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["serviceDurationPriceRequired"];
            }];
        };
    };
    export default serviceCreatePagePlan;
}
declare module "_102042_/l2/barbershopPro/staffCreate.defs" {
    export const staffCreatePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "staffCreate";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 76;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "staffCreate";
                readonly pageName: "New staff member";
                readonly actor: "manager";
                readonly purpose: "Add a new staff member to the roster.";
                readonly capabilities: readonly ["manageStaff"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["staffMember"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "staffList";
                    readonly trigger: "New staff member";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "staffList";
                    readonly trigger: "Staff member created";
                    readonly description: "Return to staff list after successful creation.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "staffIdentity";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "staffIdentityForm";
                        readonly purpose: "Capture staff member identity and contact details.";
                        readonly userActions: readonly ["Enter name", "Enter contact info", "Select status"];
                        readonly requiredEntities: readonly ["StaffMember"];
                        readonly readsFields: readonly ["StaffMember.firstName", "StaffMember.lastName", "StaffMember.email", "StaffMember.phone", "StaffMember.status"];
                        readonly writesFields: readonly ["StaffMember.firstName", "StaffMember.lastName", "StaffMember.email", "StaffMember.phone", "StaffMember.status"];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }, {
                    readonly sectionName: "roleAndCommission";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "roleAssignmentForm";
                        readonly purpose: "Assign role and permissions for the staff member.";
                        readonly userActions: readonly ["Select role", "Set permissions scope"];
                        readonly requiredEntities: readonly ["StaffMember"];
                        readonly readsFields: readonly ["StaffMember.role", "StaffMember.permissionsScope"];
                        readonly writesFields: readonly ["StaffMember.role", "StaffMember.permissionsScope"];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }, {
                        readonly organismName: "commissionSettingsForm";
                        readonly purpose: "Configure commission rule for the staff member.";
                        readonly userActions: readonly ["Select commission type", "Set commission rate", "Set commission effective date"];
                        readonly requiredEntities: readonly ["CommissionRule"];
                        readonly readsFields: readonly ["CommissionRule.type", "CommissionRule.rate", "CommissionRule.effectiveDate"];
                        readonly writesFields: readonly ["CommissionRule.type", "CommissionRule.rate", "CommissionRule.effectiveDate"];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }, {
                    readonly sectionName: "createActions";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "createStaffMemberAction";
                        readonly purpose: "Submit staff member creation.";
                        readonly userActions: readonly ["Create staff member"];
                        readonly requiredEntities: readonly ["StaffMember", "CommissionRule"];
                        readonly readsFields: readonly ["StaffMember.firstName", "StaffMember.lastName", "StaffMember.email", "StaffMember.phone", "StaffMember.status", "StaffMember.role", "StaffMember.permissionsScope", "CommissionRule.type", "CommissionRule.rate", "CommissionRule.effectiveDate"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "createStaffMember";
                readonly purpose: "Create a staff member record.";
                readonly kind: "command";
                readonly input: {
                    readonly staffMember: {
                        readonly firstName: "string";
                        readonly lastName: "string";
                        readonly email: "string";
                        readonly phone: "string";
                        readonly status: "string";
                        readonly role: "string";
                        readonly permissionsScope: "string";
                    };
                    readonly commissionRule: {
                        readonly type: "string";
                        readonly rate: "number";
                        readonly effectiveDate: "string";
                    };
                };
                readonly output: {
                    readonly staffMemberId: "string";
                    readonly staffMemberProfile: {
                        readonly staffMemberId: "string";
                        readonly firstName: "string";
                        readonly lastName: "string";
                        readonly role: "string";
                        readonly status: "string";
                    };
                    readonly commissionRuleId: "string";
                };
                readonly readsEntities: readonly ["StaffMember", "CommissionRule"];
                readonly writesEntities: readonly ["StaffMember", "CommissionRule"];
                readonly readsTables: readonly ["staff_member", "commission_rule"];
                readonly writesTables: readonly ["staff_member", "commission_rule", "performance_metrics"];
                readonly usecaseRefs: readonly ["createStaffMemberUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_singleLocationScope"];
            }];
        };
    };
    export default staffCreatePagePlan;
}
declare module "_102042_/l2/barbershopPro/staffPerformance.defs" {
    export const staffPerformancePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "staffPerformance";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 93;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "staffPerformance";
                readonly pageName: "Staff performance";
                readonly actor: "manager";
                readonly purpose: "Review staff performance metrics and commissions.";
                readonly capabilities: readonly ["viewStaffPerformance"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["staffMember"];
                readonly pageInputs: readonly [{
                    readonly name: "dateRange";
                    readonly type: "dateRange";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "userSelection"];
                    readonly description: "Date range for performance metrics.";
                }];
                readonly navigationRefs: readonly [];
                readonly sections: readonly [{
                    readonly sectionName: "Performance filters";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "dateRangeFilter";
                        readonly purpose: "Select the time window for staff performance metrics.";
                        readonly userActions: readonly ["Select date range", "Apply filters"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Staff performance summary";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "staffPerformanceTable";
                        readonly purpose: "Display performance metrics and commission summaries by staff member.";
                        readonly userActions: readonly ["View staff performance metrics"];
                        readonly requiredEntities: readonly ["StaffMember"];
                        readonly readsFields: readonly ["performanceMetrics.staffMember", "performanceMetrics.commissionAmount", "performanceMetrics.serviceRevenue", "performanceMetrics.productRevenue", "performanceMetrics.totalRevenue", "performanceMetrics.saleCount", "performanceMetrics.unitsSold"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["commissionCalculationRequired", "singleLocationScope"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getStaffPerformance";
                readonly purpose: "Load staff performance metrics.";
                readonly kind: "query";
                readonly input: {
                    readonly dateRange: {
                        readonly start: "timestamptz";
                        readonly end: "timestamptz";
                    };
                };
                readonly output: {
                    readonly staffPerformance: readonly [{
                        readonly staffMemberId: "uuid";
                        readonly commissionAmount: "numeric";
                        readonly serviceRevenue: "numeric";
                        readonly productRevenue: "numeric";
                        readonly totalRevenue: "numeric";
                        readonly saleCount: "integer";
                        readonly unitsSold: "integer";
                    }];
                    readonly totals: {
                        readonly commissionAmount: "numeric";
                        readonly serviceRevenue: "numeric";
                        readonly productRevenue: "numeric";
                        readonly totalRevenue: "numeric";
                        readonly saleCount: "integer";
                        readonly unitsSold: "integer";
                    };
                };
                readonly readsEntities: readonly ["Sale", "StaffMember", "CommissionRule"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["viewStaffPerformanceUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["commissionCalculationRequired", "singleLocationScope"];
            }];
        };
    };
    export default staffPerformancePagePlan;
}
declare module "_102042_/l2/barbershopPro/upsellSuggestions.defs" {
    export const upsellSuggestionsPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "upsellSuggestions";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 95;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "upsellSuggestions";
                readonly pageName: "Upsell suggestions";
                readonly actor: "receptionist";
                readonly purpose: "Request and review upsell suggestions for a customer.";
                readonly capabilities: readonly ["llmRecommendations"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly ["upsellSuggestion"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["pluginLlmUpsell"];
                readonly mdmRefs: readonly ["customer", "service", "product"];
                readonly pageInputs: readonly [{
                    readonly name: "customerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Customer to generate upsell suggestions for.";
                    readonly entityRef: "Customer";
                    readonly fieldRef: "Customer.id";
                }, {
                    readonly name: "appointmentId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult", "query"];
                    readonly description: "Appointment context if suggestions are tied to a scheduled visit.";
                    readonly entityRef: "Appointment";
                    readonly fieldRef: "Appointment.id";
                }, {
                    readonly name: "serviceId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult", "query"];
                    readonly description: "Current service context when there is no appointment.";
                    readonly entityRef: "Service";
                    readonly fieldRef: "Service.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "recordSale";
                    readonly trigger: "Add upsell item";
                    readonly description: "Proceed to record a sale with the selected upsell item.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Upsell request";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "UpsellRequestForm";
                        readonly purpose: "Capture customer and service context to request upsell suggestions.";
                        readonly userActions: readonly ["Request upsell suggestions"];
                        readonly requiredEntities: readonly ["Customer", "Service", "Sale"];
                        readonly readsFields: readonly ["Customer.id", "Appointment.id", "Service.id"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }, {
                    readonly sectionName: "Suggested upsell items";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "UpsellSuggestionList";
                        readonly purpose: "Show recommended services or products with rationale.";
                        readonly userActions: readonly ["Add upsell item", "Dismiss upsell suggestion", "Retry upsell suggestion"];
                        readonly requiredEntities: readonly ["Service"];
                        readonly readsFields: readonly ["Service.id", "Service.name", "Service.price", "UpsellSuggestion.rationale"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "requestUpsellSuggestions";
                readonly purpose: "Get upsell recommendations for a customer.";
                readonly kind: "command";
                readonly input: {
                    readonly customerId: "string";
                    readonly "appointmentId?": "string";
                    readonly "serviceId?": "string";
                };
                readonly output: {
                    readonly status: "string";
                    readonly suggestions: readonly [{
                        readonly serviceId: "string";
                        readonly name: "string";
                        readonly price: "number";
                        readonly rationale: "string";
                    }];
                    readonly requestedAt: "string";
                };
                readonly readsEntities: readonly ["Customer", "Service", "Sale"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["requestUpsellSuggestionUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_singleLocationScope"];
            }];
        };
    };
    export default upsellSuggestionsPagePlan;
}
declare module "_102042_/l2/barbershopPro/walkInSlotSuggestions.defs" {
    export const walkInSlotSuggestionsPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "walkInSlotSuggestions";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 94;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "walkInSlotSuggestions";
                readonly pageName: "Walk-in slot suggestions";
                readonly actor: "receptionist";
                readonly purpose: "Request and review suggested walk-in time slots.";
                readonly capabilities: readonly ["llmRecommendations"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly ["walkInSlotSuggestion"];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly ["llmWalkInSlot"];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "desiredDate";
                    readonly type: "date";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "previousStepResult"];
                    readonly description: "Preferred date to request walk-in suggestions for.";
                }, {
                    readonly name: "servicePreference";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["queryParam", "previousStepResult"];
                    readonly description: "Preferred service for the walk-in request.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "appointmentBooking";
                    readonly trigger: "Book suggested slot";
                    readonly description: "Start booking for a selected suggested slot.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Request walk-in suggestions";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "walkInSlotRequestForm";
                        readonly purpose: "Capture desired date and service to request walk-in slot suggestions.";
                        readonly userActions: readonly ["Request walk-in time slots", "Refresh suggestions"];
                        readonly requiredEntities: readonly ["AvailabilitySlot", "StaffMember"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }, {
                    readonly sectionName: "Suggested time slots";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "walkInSlotSuggestionList";
                        readonly purpose: "Display recommended walk-in time slots and allow selection for booking.";
                        readonly userActions: readonly ["Select suggested slot", "Book suggested slot"];
                        readonly requiredEntities: readonly ["AvailabilitySlot", "StaffMember"];
                        readonly readsFields: readonly ["AvailabilitySlot.startTime", "AvailabilitySlot.endTime", "AvailabilitySlot.staffMemberId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_singleLocationScope"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "requestWalkInSlotSuggestions";
                readonly purpose: "Get walk-in slot recommendations.";
                readonly kind: "command";
                readonly input: {
                    readonly desiredDate: "date";
                    readonly servicePreference: "string";
                };
                readonly output: {
                    readonly suggestions: readonly [{
                        readonly availabilitySlotId: "string";
                        readonly startTime: "datetime";
                        readonly endTime: "datetime";
                        readonly staffMemberId: "string";
                        readonly staffMemberName: "string";
                        readonly confidenceScore: "number";
                    }];
                };
                readonly readsEntities: readonly ["AvailabilitySlot", "Appointment", "StaffMember"];
                readonly writesEntities: readonly ["AvailabilitySlot"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["requestWalkInSlotsUsecase"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_singleLocationScope"];
            }];
        };
    };
    export default walkInSlotSuggestionsPagePlan;
}
declare module "_102042_/l2/barbershopPro/plugins/llmWalkInSlot.defs" {
    export const llmWalkInSlotPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "llmWalkInSlot";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llmWalkInSlot";
                readonly provider: "Llm Walk In Slot";
                readonly priority: "soon";
                readonly reason: "Supports walk-in slot recommendations after core scheduling is live.";
                readonly events: readonly [];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly [];
                readonly outputData: readonly [];
                readonly webhooks: readonly [];
                readonly risks: readonly [];
                readonly questions: readonly [];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102042_/l2/plugins/llmWalkInSlot/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102042_/l2/barbershopPro/plugins/llmWalkInSlot.defs.ts";
            };
        };
    };
    export default llmWalkInSlotPluginConnectionPlan;
}
declare module "_102042_/l2/barbershopPro/plugins/pluginLlmUpsell.defs" {
    export const pluginLlmUpsellPluginConnectionPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginConnection";
        readonly artifactId: "pluginLlmUpsell";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginLlmUpsell";
                readonly provider: "Plugin Llm Upsell";
                readonly priority: "soon";
                readonly reason: "Supports the upsell feature once data sources are confirmed.";
                readonly events: readonly [];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly [];
                readonly outputData: readonly [];
                readonly webhooks: readonly [];
                readonly risks: readonly [];
                readonly questions: readonly [];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102042_/l2/plugins/pluginLlmUpsell/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102042_/l2/barbershopPro/plugins/pluginLlmUpsell.defs.ts";
            };
        };
    };
    export default pluginLlmUpsellPluginConnectionPlan;
}
declare module "_102042_/l2/plugins/llmWalkInSlot/plugin.defs" {
    export const llmWalkInSlotPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "llmWalkInSlot";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "llmWalkInSlot";
                readonly provider: "Llm Walk In Slot";
                readonly priority: "soon";
                readonly reason: "Supports walk-in slot recommendations after core scheduling is live.";
                readonly events: readonly [];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly [];
                readonly outputData: readonly [];
                readonly webhooks: readonly [];
                readonly risks: readonly [];
                readonly questions: readonly [];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102042_/l2/plugins/llmWalkInSlot/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102042_/l2/barbershopPro/plugins/llmWalkInSlot.defs.ts";
            };
        };
    };
    export default llmWalkInSlotPluginPlan;
}
declare module "_102042_/l2/plugins/pluginLlmUpsell/plugin.defs" {
    export const pluginLlmUpsellPluginPlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "pluginDraft";
        readonly artifactId: "pluginLlmUpsell";
        readonly moduleName: "barbershopPro";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPlugins";
            readonly stepId: 36;
            readonly planId: "plan-index-critic:pluginPlan:1";
        };
        readonly data: {
            readonly plugin: {
                readonly pluginId: "pluginLlmUpsell";
                readonly provider: "Plugin Llm Upsell";
                readonly priority: "soon";
                readonly reason: "Supports the upsell feature once data sources are confirmed.";
                readonly events: readonly [];
                readonly requiredCredentials: readonly [];
                readonly inputData: readonly [];
                readonly outputData: readonly [];
                readonly webhooks: readonly [];
                readonly risks: readonly [];
                readonly questions: readonly [];
                readonly resolution: "create_draft";
                readonly pluginDefsFileRef: "_102042_/l2/plugins/pluginLlmUpsell/plugin.defs.ts";
                readonly moduleConnectionDefsFileRef: "_102042_/l2/barbershopPro/plugins/pluginLlmUpsell.defs.ts";
            };
        };
    };
    export default pluginLlmUpsellPluginPlan;
}
