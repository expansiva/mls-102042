export const appointmentBookingDef = {
  "schemaVersion": "2026-06-06",
  "artifactType": "workflow",
  "artifactId": "appointmentBooking",
  "moduleName": "barbershopPro",
  "status": "draft",
  "source": {
    "agentName": "agentPlanWorkflowDefinition",
    "stepId": 57,
    "planId": ""
  },
  "data": {
    "workflowDefinition": {
      "workflowId": "appointmentBooking",
      "title": "Appointment booking",
      "purpose": "Manage the full appointment lifecycle from creation through rescheduling and cancellation while enforcing staff availability and preventing overlapping bookings.",
      "executionMode": "entityLifecycle",
      "createsTask": false,
      "taskConfig": {
        "taskTitleTemplate": "",
        "assigneeRules": [],
        "slaRules": [],
        "taskRoomRequired": false
      },
      "actors": [
        "receptionist"
      ],
      "states": [
        {
          "stateId": "draft",
          "description": "Appointment is being prepared and not yet confirmed."
        },
        {
          "stateId": "booked",
          "description": "Appointment is confirmed and holds a time slot."
        },
        {
          "stateId": "checkedIn",
          "description": "Customer has arrived and appointment is in progress."
        },
        {
          "stateId": "completed",
          "description": "Service has been delivered and appointment is closed."
        },
        {
          "stateId": "cancelled",
          "description": "Appointment is cancelled and time slot is released."
        },
        {
          "stateId": "noShow",
          "description": "Customer did not arrive and appointment is marked as no-show."
        }
      ],
      "transitions": [
        {
          "from": "draft",
          "to": "booked",
          "trigger": "bookAppointment",
          "actor": "receptionist",
          "conditions": [
            "appointmentMustHaveCustomerStaffService",
            "appointmentNoOverlapPerStaff",
            "singleLocationScope"
          ],
          "actions": [
            "set Appointment.lifecycleState=booked",
            "set AvailabilitySlot.status=booked"
          ],
          "rulesApplied": [
            "appointmentMustHaveCustomerStaffService",
            "appointmentNoOverlapPerStaff",
            "singleLocationScope"
          ]
        },
        {
          "from": "booked",
          "to": "booked",
          "trigger": "rescheduleAppointment",
          "actor": "receptionist",
          "conditions": [
            "appointmentNoOverlapPerStaff",
            "singleLocationScope"
          ],
          "actions": [
            "set Appointment.lifecycleState=booked"
          ],
          "rulesApplied": [
            "appointmentNoOverlapPerStaff",
            "singleLocationScope"
          ]
        },
        {
          "from": "booked",
          "to": "cancelled",
          "trigger": "cancelAppointment",
          "actor": "receptionist",
          "conditions": [
            "singleLocationScope"
          ],
          "actions": [
            "set Appointment.lifecycleState=cancelled",
            "set AvailabilitySlot.status=available"
          ],
          "rulesApplied": [
            "singleLocationScope"
          ]
        }
      ],
      "requiredEntities": [
        "Appointment",
        "AvailabilitySlot",
        "Customer",
        "StaffMember",
        "Service"
      ],
      "persistenceRefs": [
        "availabilitySlot"
      ],
      "usecaseRefs": [
        "bookAppointmentUsecase",
        "rescheduleAppointmentUsecase",
        "cancelAppointmentUsecase"
      ],
      "metricRefs": [
        "operationsMetrics"
      ],
      "userActions": [
        "bookAppointment",
        "rescheduleAppointment",
        "cancelAppointment"
      ],
      "relatedPages": [],
      "relatedAgents": [],
      "relatedPlugins": [],
      "rulesApplied": [
        "appointmentMustHaveCustomerStaffService",
        "appointmentNoOverlapPerStaff",
        "singleLocationScope"
      ],
      "implementationSuggestions": [
        {
          "suggestionId": "validateAvailabilityBeforeBook",
          "title": "Validate availability before booking",
          "priority": "now",
          "description": "Enforce appointmentNoOverlapPerStaff by verifying the candidate availability_slot is available within bookAppointmentUsecase and rescheduleAppointmentUsecase.",
          "tradeoff": "Adds extra read checks but prevents double-booking."
        },
        {
          "suggestionId": "atomicSlotUpdate",
          "title": "Atomically update availability slot on book/reschedule",
          "priority": "now",
          "description": "Wrap appointment and availability_slot updates in a single transaction to keep slot status aligned with appointment state during concurrent updates.",
          "tradeoff": "Requires transactional locking or retry logic under heavy load."
        },
        {
          "suggestionId": "noTaskNeededForBooking",
          "title": "No task creation for appointment booking",
          "priority": "soon",
          "description": "Keep createsTask=false because receptionist completes booking in the same flow without asynchronous fulfillment; use notifications instead of task queues if needed.",
          "tradeoff": "Less visibility in task dashboards but reduced overhead."
        }
      ],
      "workflowScope": "singleModule",
      "moduleRefs": [
        "barbershopPro"
      ],
      "pageRefsByModule": [],
      "entityRefsByModule": [
        {
          "moduleId": "barbershopPro",
          "entity": "Appointment"
        },
        {
          "moduleId": "barbershopPro",
          "entity": "AvailabilitySlot"
        },
        {
          "moduleId": "barbershopPro",
          "entity": "Customer"
        },
        {
          "moduleId": "barbershopPro",
          "entity": "StaffMember"
        },
        {
          "moduleId": "barbershopPro",
          "entity": "Service"
        }
      ],
      "writesArtifacts": [
        {
          "moduleId": "barbershopPro",
          "artifactType": "workflow",
          "artifactId": "appointmentBooking"
        },
        {
          "moduleId": "barbershopPro",
          "artifactType": "table",
          "artifactId": "availabilitySlot"
        },
        {
          "moduleId": "barbershopPro",
          "artifactType": "metricTable",
          "artifactId": "operationsMetrics"
        },
        {
          "moduleId": "barbershopPro",
          "artifactType": "usecase",
          "artifactId": "bookAppointmentUsecase"
        },
        {
          "moduleId": "barbershopPro",
          "artifactType": "usecase",
          "artifactId": "rescheduleAppointmentUsecase"
        },
        {
          "moduleId": "barbershopPro",
          "artifactType": "usecase",
          "artifactId": "cancelAppointmentUsecase"
        }
      ]
    },
    "defsPlan": {
      "fileName": "workflows/appointmentBooking.defs.ts",
      "exportName": "appointmentBookingDef",
      "saveAsDefs": true
    }
  }
} as const;

export default appointmentBookingDef;
