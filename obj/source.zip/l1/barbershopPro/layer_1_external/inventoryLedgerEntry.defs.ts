export const inventoryLedgerEntryTableDefinition = {
  "schemaVersion": "2026-06-06",
  "artifactType": "table",
  "artifactId": "inventoryLedgerEntry",
  "moduleName": "barbershopPro",
  "status": "draft",
  "source": {
    "agentName": "agentPlanTableDefinition",
    "stepId": 43,
    "planId": "plan-table-definition:inventoryLedgerEntry"
  },
  "data": {
    "tableDefinition": {
      "tableId": "inventoryLedgerEntry",
      "tableName": "inventory_ledger_entry",
      "moduleId": "barbershopPro",
      "title": "Inventory ledger entry",
      "purpose": "Record stock changes for product sales and manual adjustments.",
      "ownership": "moduleOwned",
      "rootEntity": "InventoryLedger",
      "layer": "layer_1_external",
      "tableKind": "transactional",
      "columns": [
        {
          "name": "inventory_ledger_entry_id",
          "type": "uuid",
          "nullable": false,
          "primaryKey": true,
          "description": "Primary key for inventory ledger entry."
        },
        {
          "name": "product_id",
          "type": "uuid",
          "nullable": false,
          "description": "Product whose stock changed."
        },
        {
          "name": "sale_id",
          "type": "uuid",
          "nullable": true,
          "description": "Sale that caused the stock change, if applicable."
        },
        {
          "name": "change_type",
          "type": "text",
          "nullable": false,
          "description": "Reason category for the stock change (sale, adjustment, correction)."
        },
        {
          "name": "quantity_change",
          "type": "integer",
          "nullable": false,
          "description": "Signed quantity delta applied to stock."
        },
        {
          "name": "balance_after",
          "type": "integer",
          "nullable": false,
          "description": "Resulting stock level after applying this entry."
        },
        {
          "name": "entry_status",
          "type": "text",
          "nullable": false,
          "default": "posted",
          "description": "Lifecycle status of the ledger entry."
        },
        {
          "name": "effective_at",
          "type": "timestamptz",
          "nullable": false,
          "description": "When the stock change becomes effective."
        },
        {
          "name": "created_at",
          "type": "timestamptz",
          "nullable": false,
          "description": "When the ledger entry was recorded."
        }
      ],
      "primaryKey": [
        "inventory_ledger_entry_id"
      ],
      "foreignRefs": [
        {
          "fieldName": "product_id",
          "targetEntity": "Product",
          "targetOwnership": "mdmOwned",
          "reason": "Link entry to product for stock tracking."
        },
        {
          "fieldName": "sale_id",
          "targetEntity": "Sale",
          "targetOwnership": "mdmOwned",
          "reason": "Link entry to originating sale when applicable."
        }
      ],
      "indexes": [
        {
          "indexName": "idx_inventory_ledger_entry_product_effective",
          "columns": [
            "product_id",
            "effective_at"
          ],
          "reason": "Lookup product ledger history and filter by date on inventory and checkout views."
        },
        {
          "indexName": "idx_inventory_ledger_entry_sale",
          "columns": [
            "sale_id"
          ],
          "reason": "Resolve ledger entries created by a sale."
        },
        {
          "indexName": "idx_inventory_ledger_entry_status",
          "columns": [
            "entry_status"
          ],
          "reason": "Filter by lifecycle status for operational workflows."
        }
      ],
      "detailsColumn": {
        "enabled": false
      },
      "metricUpdatePolicy": {
        "feedsMetrics": true,
        "metricRefs": [
          "inventoryLevelByProduct",
          "inventoryAdjustmentsCount"
        ],
        "updatedByLayer": "layer_3_usecases"
      },
      "accessPolicy": {
        "directAccessAllowedFor": [
          "layer_3_usecases"
        ],
        "forbiddenFor": [
          "pages",
          "layer_2_controllers",
          "agents"
        ]
      },
      "rulesApplied": [
        "inventoryCannotGoNegative",
        "singleLocationScope"
      ]
    },
    "defsPlan": {
      "fileName": "tables/inventoryLedgerEntry.defs.ts",
      "exportName": "inventoryLedgerEntryTableDefinition",
      "saveAsDefs": true
    }
  }
} as const;

export default inventoryLedgerEntryTableDefinition;
