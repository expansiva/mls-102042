export const appointmentCheckoutPagePlan = {
  "schemaVersion": "2026-06-06",
  "artifactType": "page",
  "artifactId": "appointmentCheckout",
  "moduleName": "barbershopPro",
  "status": "draft",
  "source": {
    "agentName": "agentPlanPageDefinition",
    "stepId": 88,
    "planId": ""
  },
  "data": {
    "pageDefinition": {
      "pageId": "appointmentCheckout",
      "pageName": "Complete appointment",
      "actor": "receptionist",
      "purpose": "Finalize the appointment and prepare for sale recording.",
      "capabilities": [
        "checkInAndCheckout"
      ],
      "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [
          "checkInCheckout"
        ],
        "taskWorkflows": [],
        "automations": []
      },
      "pluginRefs": [],
      "mdmRefs": [
        "customer",
        "staffMember",
        "service"
      ],
      "pageInputs": [
        {
          "name": "appointmentId",
          "type": "string",
          "required": true,
          "sources": [
            "routeParam",
            "previousStepResult"
          ],
          "description": "Appointment identifier to complete.",
          "entityRef": "Appointment",
          "fieldRef": "Appointment.appointmentId"
        },
        {
          "name": "appointmentSummary",
          "type": "object",
          "required": false,
          "sources": [
            "previousStepResult",
            "cache"
          ],
          "description": "Summary details from the prior step for display before completion.",
          "entityRef": "Appointment"
        }
      ],
      "navigationRefs": [
        {
          "direction": "inbound",
          "pageId": "appointmentDetail",
          "trigger": "Complete appointment"
        },
        {
          "direction": "outbound",
          "pageId": "recordSale",
          "trigger": "Proceed to sale"
        }
      ],
      "sections": [
        {
          "sectionName": "Appointment summary",
          "mode": "view",
          "organisms": [
            {
              "organismName": "appointmentSummaryCard",
              "purpose": "Show the appointment details to confirm before completion.",
              "userActions": [
                "Review appointment details"
              ],
              "requiredEntities": [
                "Appointment"
              ],
              "readsFields": [
                "Appointment.appointmentId",
                "Appointment.status",
                "Appointment.customerId",
                "Appointment.staffMemberId",
                "Appointment.serviceId",
                "Appointment.startTime",
                "Appointment.endTime"
              ],
              "writesFields": [],
              "rulesApplied": []
            }
          ]
        },
        {
          "sectionName": "Complete appointment",
          "mode": "action",
          "organisms": [
            {
              "organismName": "completeAppointmentAction",
              "purpose": "Mark the appointment as completed to enable sale recording.",
              "userActions": [
                "Complete appointment"
              ],
              "requiredEntities": [
                "Appointment"
              ],
              "readsFields": [
                "Appointment.appointmentId",
                "Appointment.status"
              ],
              "writesFields": [
                "Appointment.status"
              ],
              "rulesApplied": [
                "RULE_singleLocationScope"
              ]
            }
          ]
        }
      ]
    },
    "bffCommands": [
      {
        "commandName": "completeAppointment",
        "purpose": "Mark appointment as completed.",
        "kind": "mutation",
        "input": {
          "appointmentId": "string"
        },
        "output": {
          "appointment": {
            "appointmentId": "string",
            "status": "string"
          }
        },
        "readsEntities": [
          "Appointment"
        ],
        "writesEntities": [
          "Appointment"
        ],
        "readsTables": [
          "appointment"
        ],
        "writesTables": [
          "appointment",
          "operations_metrics"
        ],
        "usecaseRefs": [
          "completeAppointmentUsecase"
        ],
        "layerContract": {
          "controllerLayer": "layer_2_controllers",
          "mustCallLayer": "layer_3_usecases",
          "directTableAccessForbidden": true
        },
        "rulesApplied": [
          "RULE_singleLocationScope"
        ]
      }
    ]
  }
} as const;

export default appointmentCheckoutPagePlan;
